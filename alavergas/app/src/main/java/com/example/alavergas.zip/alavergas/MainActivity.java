package com.example.alavergas;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private SceneManager sceneManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar el administrador de la escena
        sceneManager = new SceneManager(this, findViewById(R.id.sceneView));
        sceneManager.loadModel("file:///android_asset/carro.glb");
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            sceneManager.resume();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sceneManager.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        sceneManager.destroy();
    }
}
